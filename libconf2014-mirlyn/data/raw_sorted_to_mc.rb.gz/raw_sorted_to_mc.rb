require 'line_iterator'

class PrefixBasedRecordIterator < LineIterator
  PREFIXP = /^(\d+)\s+/
  def prefix(line)
    (PREFIXP.match(line))[1]
  end

  def end_of_record(buff)
    return true if self.done
    line, line_no = peek
    p = prefix(line)
    if p != @previous_prefix
      @previous_prefix = p
      return  !(buff.empty?)
    else
      return false
    end
  end
end

iter = PrefixBasedRecordIterator.new('raw_sorted.txt')

search_sessions = File.open('search_session_mc.txt', 'w:utf-8')
non_search_sessions = File.open('nonsearch_session_mc.txt', 'w:utf-8')
singles = File.open('singles_session_mc.txt', 'w:utf-8')

def isn_search?(line)
  (line[1] == '2') and (line[2] == 'isn')
end

mixed = 0

iter.each_record do |r|
  r = r.map {|x| x.chomp.split(/\t/)}
  first = r.shift
  isn = isn_search?(first)
  h = {:session => first[0], :date => first[-2], :size=>1, :actions=>[first[1]]}
  r.each do |action|
    h[:size] += 1
    h[:actions] << action[1]
    isn = true if isn_search?(action)
  end

  next if isn # skip those sessions with an isn search
  next if h[:actions].include? '50'
  
  output = [h[:session], h[:date], h[:size], [':', h[:actions].join(':'), ':'].join('')].join("\t")

  if h[:size] == 1
    singles.puts output
    next
  end

  if h[:actions].include? '2'
    search_sessions.puts output
    if h[:actions].uniq != ['2']
      mixed += 1
    end
  else
    non_search_sessions.puts output
  end
end

puts "Total mixed is #{mixed}"

  